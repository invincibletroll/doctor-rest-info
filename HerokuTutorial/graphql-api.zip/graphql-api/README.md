# MU-UW-Labs-GraphQL-Solution

Sample solution for [GralphQL labs](https://github.com/manulife-ca/mu-uw-labs-graphql)

## How to run

```bash
npm i
```

Once installation is done, run

```bash
npm start
```


