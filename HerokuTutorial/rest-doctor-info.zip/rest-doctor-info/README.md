# doctor-info

## local setup
Requires nodemon to be install globally:

```
npm install -g nodemon
```

### Running the server
To run the server, run:

```
npm start
```

To view the Swagger UI interface:

```
open http://localhost:8080/docs
```

Swagger api [location](./config/swagger.json)
